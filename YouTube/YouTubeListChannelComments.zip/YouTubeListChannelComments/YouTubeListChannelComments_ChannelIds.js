var YourApiKey = "AIzaSyBRh57FMz0WEtAXjbvTYqoSlNYmQgPP4kg"; // Dan's API Key - replace with yours when you get it
// var YourChannelId =  "UCNrOncgOf5oFGH4lP8jzUtA"; // TNW
var YourChannelId =  "UCXRNHTVpEdhz9BIvomETGiQ"; // NLC
